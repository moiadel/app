from flask_sqlalchemy import SQLAlchemy
from models.user import User

db = SQLAlchemy()

# récupération des données dans la base de données


def get_users():
    return User.query.all()


def get_todo_by_id(todo_id):
    return todo_id


def create_user(user):
    db.session.add(user)
    db.session.commit()
    return "Utilisateur crée"


def update_todo(todo_id):
    return todo_id


def delete_todo(todo_id):
    return todo_id
