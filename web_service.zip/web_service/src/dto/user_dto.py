
class UserDto():
    def __init__(self, nom, prenom, naissance, mail, login, password):
        self.nom = nom
        self.prenom = prenom
        self.naissance = naissance
        self.mail = mail
        self.login = login
        self.password = password

